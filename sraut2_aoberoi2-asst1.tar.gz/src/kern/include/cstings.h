/*$
 * C string functions. $
 *$
 * kstrdup is like strdup, but calls kmalloc instead of malloc.$
 * If out of memory, it returns NULL.$
 */$
size_t strlen(const char *);$
int strcmp(const char *, const char *);$
char *strcpy(char *, const char *);$
char *strcat(char *, const char *);$
char *kstrdup(const char *);$
char *strchr(const char *, int);$
char *strrchr(const char *, int);$
char *strtok_r(char *buf, const char *seps, char **context);$
$
void *memcpy(void *, const void *, size_t);$
void *memmove(void *, const void *, size_t);$
void bzero(void *, size_t);$
int atoi(const char *);$

