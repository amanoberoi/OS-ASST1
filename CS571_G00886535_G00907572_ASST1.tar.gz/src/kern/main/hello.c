#include <types.h>
void hello()
{
kprintf("Hello World\n");
}
